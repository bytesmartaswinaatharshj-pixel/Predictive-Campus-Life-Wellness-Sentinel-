# Predictive Campus Life Wellness Sentinel

A machine learning-based early-warning system designed to identify declining student campus engagement and behavioral patterns by analyzing aggregated campus-life indicators such as facility usage, dining activity, event participation, social interactions, residence engagement, and trend metrics.

> **Note:** This project uses synthetic data and is intended solely as a behavioral early-warning prototype. It is **not a clinical mental-health diagnosis system**.

---

## 📌 Overview

Educational institutions require proactive mechanisms to understand shifting student participation levels so that potential disengagement patterns can be identified early.

The **Predictive Campus Life Wellness Sentinel** provides an end-to-end machine learning pipeline that:

- Generates a synthetic multi-week student behavioral dataset.
- Preprocesses features and computes dynamic, trend-based indicators.
- Trains and compares **Random Forest** and **XGBoost** classification models.
- Prioritizes **High-risk recall** during model comparison.
- Serializes the selected model for reuse.
- Tests the pretrained model using new student profiles.
- Exposes predictions through a **Flask REST API**.
- Provides an interactive **Streamlit** interface for risk prediction.

---

## 🎯 Objectives

- **Dataset Generation:** Produce realistic, multi-week synthetic student behavioral data.
- **Feature Engineering:** Build trend-based features such as percentage changes and rolling engagement.
- **Risk Classification:** Classify student risk into **Low (0)**, **Medium (1)**, and **High (2)**.
- **Model Comparison:** Compare Random Forest and XGBoost performance.
- **High-risk Detection:** Give particular attention to High-risk recall for this early-warning use case.
- **Model Reusability:** Save the trained model so it can be reused without retraining.
- **Independent Testing:** Verify predictions using the pretrained model.
- **API Integration:** Provide predictions through a Flask REST API.
- **User Interface:** Provide an interactive Streamlit interface connected to the API.
- **Modular Architecture:** Keep dataset generation, training, testing, and deployment in separate notebooks.

---

## 🏗️ Project Architecture

```text
                    ┌────────────────────────────┐
                    │   Synthetic Dataset        │
                    │   Generation Notebook      │
                    └──────────────┬─────────────┘
                                   │
                                   ▼
                    ┌────────────────────────────┐
                    │ Data Preprocessing &        │
                    │ Feature Engineering         │
                    └──────────────┬─────────────┘
                                   │
                                   ▼
                    ┌────────────────────────────┐
                    │ Model Training Notebook    │
                    │                            │
                    │ • Random Forest            │
                    │ • XGBoost                  │
                    │ • Evaluation               │
                    └──────────────┬─────────────┘
                                   │
                                   ▼
                    ┌────────────────────────────┐
                    │  Trained Random Forest     │
                    │  Model (.pkl)              │
                    └──────────────┬─────────────┘
                                   │
                         ┌─────────┴─────────┐
                         ▼                   ▼
              ┌──────────────────┐   ┌──────────────────┐
              │ Model Testing    │   │ Flask REST API   │
              │ Notebook         │   │ /predict         │
              └──────────────────┘   └────────┬─────────┘
                                              │
                                              ▼
                                    ┌────────────────────┐
                                    │ Streamlit Interface│
                                    │ Student Inputs     │
                                    │ Risk Prediction    │
                                    │ Probabilities      │
                                    └────────────────────┘
```

---

## 📂 Project Structure

```text
Predictive_Campus_Life_Wellness_Sentinel/
│
├── Dataset/
│   └── student_wellness_prediction_dataset.csv
│
├── Models/
│   └── wellness_randomforest_pipeline.pkl
│
├── Notebooks/
│   ├── dataset_generation.ipynb
│   ├── RandomForest_train.ipynb
│   ├── RandomForest_test.ipynb
│   └── RandomForest_API.ipynb
│
└── README.md
```

---

# 📓 Google Colab Notebooks

## 1. Data Generation & Preprocessing

**Notebook:** `dataset_generation.ipynb`

This notebook generates and prepares the synthetic student behavioral dataset.

### Main Tasks

- Generate synthetic multi-week student behavioral data.
- Perform preprocessing.
- Create behavioral and engagement features.
- Generate risk labels.
- Save the final dataset.
- Download the dataset for reuse.

### Dataset File

```text
student_wellness_prediction_dataset.csv
```

### Notebook

[Open Dataset Generation Notebook in Google Colab](https://colab.research.google.com/drive/1H62ejmaQou7oZp3ZrbZlhbCsAhpa1Iwa?usp=sharing)

---

# 📊 Dataset & Feature Engineering

The dataset represents student campus-life behavioral and engagement patterns across multiple weeks.

### Key Features

| Feature Name | Description |
|---|---|
| `facility_usage` | Frequency of campus facility utilization |
| `dining_activity` | Dining/cafeteria activity |
| `event_participation` | Participation in campus events and activities |
| `club_participation` | Engagement in student clubs and organizations |
| `residence_engagement` | Engagement within the residence environment |
| `recreation_activity` | Recreational activity level |
| `social_interactions` | Peer-to-peer interaction indicator |
| `communication_activity` | Campus communication and interaction frequency |
| `sleep_quality` | Behavioral sleep-quality indicator |
| `academic_engagement` | Academic participation and engagement |
| `campus_engagement_score` | Composite campus engagement indicator |
| `social_isolation_score` | Behavioral social-isolation indicator |
| `engagement_change_pct` | Percentage change in engagement from the previous period |
| `rolling_3_week_engagement` | Smoothed engagement across three weeks |

### Target Variable (`risk_label`)

```text
0 → Low Risk
1 → Medium Risk
2 → High Risk
```

Feature engineering was performed to capture **behavioral trends rather than only static values**.

- **Campus Engagement Score** summarizes overall campus participation.
- **Social Isolation Score** combines social and interaction-related indicators.
- **Engagement Change Percentage** captures increasing or declining engagement.
- **Rolling 3-Week Engagement** helps identify sustained changes and reduce temporary fluctuations.

---

# 🤖 2. Model Training, Evaluation & Serialization

**Notebook:** `RandomForest_train.ipynb`

This notebook loads the generated dataset and performs the complete model-training workflow.

### Training Workflow

```text
Load Dataset
      ↓
Data Validation
      ↓
Feature Selection
      ↓
Train/Test Split
      ↓
Random Forest Training
      ↓
XGBoost Training
      ↓
Model Evaluation
      ↓
Model Comparison
      ↓
Random Forest Selection
      ↓
Model Serialization
```

### Train/Test Strategy

- **Split Ratio:** 80% Training / 20% Testing
- **Grouping:** Student-level split to reduce data leakage between training and testing.

### Models Used

**Random Forest:** An ensemble learning algorithm that combines multiple decision trees for classification.

**XGBoost:** A gradient-boosting algorithm used as a comparison model.

### Evaluation Metrics

- Accuracy
- Precision
- Recall
- F1-score
- Confusion Matrix

### Model Comparison

Because this is an early-warning use case, **High-risk recall** was given particular attention.

In the experiment conducted on the synthetic test dataset:

| Model | High-risk Recall | Status |
|---|---:|---|
| **Random Forest** | **~40%** | Selected |
| **XGBoost** | **~17%** | Evaluated |

Based on this experiment, Random Forest was selected for the subsequent testing and API stages.

> **Note:** These results are specific to the synthetic dataset used for this prototype and serve as a proof of concept.

### Saved Model

```text
wellness_randomforest_pipeline.pkl
```

### Notebook

[Open Model Training Notebook in Google Colab](https://colab.research.google.com/drive/1bHe5q8YthHXo-Gjn1jk_FZtDK2dG5xyC?usp=sharing)

---

# 🧪 3. Pretrained Model Inference & Testing

**Notebook:** `RandomForest_test.ipynb`

This notebook independently tests the previously trained Random Forest model without retraining it.

### Testing Workflow

```text
Load Pretrained Model
        ↓
Prepare New Student Profile
        ↓
Prepare Input Features
        ↓
Run Prediction
        ↓
Generate Probability Scores
        ↓
Validate Output
```

The saved model is loaded from:

```text
wellness_randomforest_pipeline.pkl
```

New synthetic student behavioral profiles are provided to the model.

For each profile, the model generates:

- Predicted risk level
- Low probability
- Medium probability
- High probability

Example:

```text
Predicted Risk: Medium

Low:     1.18%
Medium:  62.01%
High:    36.81%
```

Multiple profiles were tested to verify that the pretrained model could perform predictions successfully without retraining.

### Notebook

[Open Model Testing Notebook in Google Colab](https://colab.research.google.com/drive/1NWg3MIQD-ytfDpCjqpVJI3545LZO-26z?usp=sharing)

---

# 🌐 4. Flask REST API & Streamlit Integration

**Notebook:** `RandomForest_API.ipynb`

This notebook integrates the pretrained Random Forest model with a **Flask REST API** and a **Streamlit interface**.

### API Workflow

```text
Student Behavioral Data
          │
          ▼
     JSON Request
          │
          ▼
    Flask /predict
          │
          ▼
Pretrained Random Forest
          │
          ▼
Risk Prediction
          │
          ▼
Probability Scores
```

## 🔌 Flask REST API

### Prediction Endpoint

```text
POST /predict
```

The endpoint accepts student behavioral data in JSON format and returns the predicted risk level and probability distribution.

### Request Body Example

```json
{
  "facility_usage": 3,
  "dining_activity": 4,
  "event_participation": 1,
  "club_participation": 1,
  "residence_engagement": 2,
  "recreation_activity": 2,
  "social_interactions": 3,
  "communication_activity": 4,
  "sleep_quality": 5,
  "academic_engagement": 6,
  "campus_engagement_score": 42.5,
  "social_isolation_score": 68.1,
  "engagement_change_pct": -18.4,
  "rolling_3_week_engagement": 45.2
}
```

### Response Example

```json
{
  "predicted_risk": "Medium",
  "probabilities": {
    "Low": 1.18,
    "Medium": 62.01,
    "High": 36.81
  }
}
```

The API was successfully tested with an **HTTP 200** response.

### API Authentication

No external API key is required for this prototype.

The Flask API is created and run locally inside the Google Colab environment and directly uses the locally loaded pretrained Random Forest model.

---

# 🖥️ Streamlit Interface

The Streamlit interface provides an interactive way to enter student behavioral information and view the model prediction.

### Streamlit Workflow

```text
User Enters Student Data
          ↓
Streamlit Interface
          ↓
Flask /predict API
          ↓
Random Forest Model
          ↓
Prediction + Probabilities
          ↓
Streamlit Result Display
```

The interface contains input fields for all **14 behavioral and engagement features**.

The results displayed include:

- Predicted risk level
- Low probability
- Medium probability
- High probability
- Probability distribution chart

### Notebook

[Open Flask API & Streamlit Notebook in Google Colab](https://colab.research.google.com/drive/1fxFzmwDIPXEUxugSSH8kgKnvjX_e5WA8?usp=sharing)

---

# 🔄 End-to-End Workflow

```text
              ┌──────────────────────┐
              │ Synthetic Data       │
              │ Generation           │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Data Preprocessing & │
              │ Feature Engineering  │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Train/Test Split     │
              │ 80% / 20%            │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Random Forest +      │
              │ XGBoost Training     │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Model Evaluation &   │
              │ Comparison            │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Random Forest        │
              │ Model (.pkl)         │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Pretrained Model     │
              │ Testing              │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Flask REST API       │
              │ /predict             │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Streamlit Interface  │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │ Risk Prediction +    │
              │ Probability Scores   │
              └──────────────────────┘
```

---

# 🛠️ Tech Stack

| Domain | Technologies |
|---|---|
| **Programming Language** | Python 3 |
| **Data Processing** | Pandas, NumPy |
| **Machine Learning** | Scikit-learn, XGBoost |
| **Model** | Random Forest Classifier |
| **Model Serialization** | Joblib |
| **Visualization** | Matplotlib |
| **Backend / API** | Flask, Flask-CORS |
| **API Communication** | Requests |
| **Frontend UI** | Streamlit |
| **Environment** | Google Colab, Jupyter Notebooks |

---

# 🚀 Execution Order

Run the notebooks in the following order:

```text
1. Notebooks/dataset_generation.ipynb
        ↓
2. Notebooks/RandomForest_train.ipynb
        ↓
3. Notebooks/RandomForest_test.ipynb
        ↓
4. Notebooks/RandomForest_API.ipynb
```

### Notebook 1
Generates the dataset:

```text
Dataset/student_wellness_prediction_dataset.csv
```

### Notebook 2
Trains the models and generates:

```text
Models/wellness_randomforest_pipeline.pkl
```

### Notebook 3
Loads the `.pkl` file independently and verifies inference on new student profiles.

### Notebook 4
Loads the pretrained model, launches the Flask REST API, and provides the Streamlit interface.

---

# 🧩 Project Challenges & Solutions

| Challenge | Solution |
|---|---|
| Real student behavioral data was unavailable | Created a synthetic dataset for prototype development |
| Student behavior changes over time | Created engagement-change and rolling-engagement features |
| Temporary behavioral changes can affect predictions | Used Rolling 3-Week Engagement |
| High-risk class is important for early warning | Focused on High-risk recall during model comparison |
| Random Forest and XGBoost produced different results | Compared both models using classification metrics |
| Model should not be retrained for every prediction | Serialized the trained Random Forest model using Joblib |
| Need to verify the saved model independently | Created a separate pretrained model testing notebook |
| Need an application interface | Created Flask REST API and Streamlit interface |
| Need a reusable project structure | Separated Dataset, Models, and Notebooks into dedicated folders |
| API does not require an external service | Flask API runs locally with the pretrained model |

---

# 📈 Key Features

- ✅ Synthetic multi-week student behavioral dataset
- ✅ Data preprocessing
- ✅ Behavioral feature engineering
- ✅ Campus engagement score
- ✅ Social isolation score
- ✅ Engagement change percentage
- ✅ Rolling 3-week engagement
- ✅ Low / Medium / High risk classification
- ✅ Random Forest classification
- ✅ XGBoost model comparison
- ✅ High-risk recall analysis
- ✅ Model serialization using `.pkl`
- ✅ Pretrained model inference
- ✅ Independent model testing
- ✅ Flask REST API
- ✅ `/predict` endpoint
- ✅ JSON input and output
- ✅ Streamlit interface
- ✅ Probability-based predictions
- ✅ Probability distribution visualization
- ✅ Modular Google Colab notebooks
- ✅ Structured project folder
- ✅ Documented and commented code

---

# ⚠️ Disclaimer & Ethical Considerations

- **Synthetic Data:** The system was trained and evaluated using synthetically generated data.
- **Non-Clinical:** The system provides behavioral engagement risk indicators only. It is **not a clinical diagnostic or mental-health assessment tool**.
- **Prototype:** The current system is intended for educational, research, internship, and prototype demonstration purposes.
- **Real-World Deployment:** Before real-world use, the system would require appropriate validation using representative institutional data, privacy protections, ethical safeguards, bias evaluation, monitoring, and qualified human oversight.
- **Human Decision-Making:** Predictions should be treated as indicators for further review and should not be used as the sole basis for decisions concerning individual students.

---

# 📚 Project Resources

## Google Colab Notebooks

### Dataset Generation
[Open Notebook](https://colab.research.google.com/drive/1H62ejmaQou7oZp3ZrbZlhbCsAhpa1Iwa?usp=sharing)

### Model Training
[Open Notebook](https://colab.research.google.com/drive/1bHe5q8YthHXo-Gjn1jk_FZtDK2dG5xyC?usp=sharing)

### Model Testing
[Open Notebook](https://colab.research.google.com/drive/1NWg3MIQD-ytfDpCjqpVJI3545LZO-26z?usp=sharing)

### Flask API & Streamlit
[Open Notebook](https://colab.research.google.com/drive/1fxFzmwDIPXEUxugSSH8kgKnvjX_e5WA8?usp=sharing)

---

# 📄 License

This project is intended for **educational, research, internship, and prototype development purposes**.
